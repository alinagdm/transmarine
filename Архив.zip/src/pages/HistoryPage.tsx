import HistoryTimeline from '../components/HistoryTimeline/HistoryTimeline';
import Footer from '../components/Footer/Footer';
import Breadcrumbs from '../components/Breadcrumbs/Breadcrumbs';
import './HistoryPage.css';

export default function HistoryPage() {
  const historySections = [
    {
      year: '1992',
      text: (
        <>
          Начало истории компании — морское агентство YANMARINE, унаследованное <br/>
          от иностранных партнёров. С этого началась «береговая» карьера команды бывших моряков, которые принесли в агентский бизнес практические знания флота <br/>
          и портовой работы. Девять специалистов <br/>
          из первого состава продолжают работать <br/>
          в ООО «ТрансМарин» сегодня.
        </>
      ),
      images: [
        { width: 320, height: 442, left: 630, top: 60, src: '/images/серт.jpg' },
        { width: 350, height: 442, left: 970, top: 60, src: '/images/Spore.png' },
      ],
      height: 562,
    },
    {
      year: (
        <>
          Март 1993 <br/>Первое судно
        </>
      ),
      text: (
        <>
          Первое судно под нашим агентированием – <br/>
          т/х «Академик Артоболевский» Латвийского МП – выгрузка в КМТП ок. 5000 тн сливочного масла из Новой Зеландии.
        </>
      ),
      images: [
        { width: 514, height: 255, left: 802, top: 100, src: '/images/telex.png' },
        { width: 515, height: 216, left: 802, top: 375, src: '/images/main.png' },
      ],
      height: 591,
    },
    {
      year: '1990-е',
      text: (
        <>
          Период активного развития <br/>
          — от агентирования трамповых судов <br/>
          до экспедирования регулярных экспортно-импортных грузопотоков: газетной бумаги в рулонах <br/>
          и целлюлозы, металлолома, минеральных удобрений, сахара и других товаров. Опыт работы с разными видами грузов заложил основу многопрофильности агентства.
        </>
      ),
      images: [
        { width: 659, height: 416, left: 661, top: 106, src: '/images/POL-America.jpg' },
      ],
      height: 562,
    },
    {
      year: '1995',
      text: (
        <>
          Начало обслуживания регулярной судоходной линии Калининград – Киль – Калининград.<br/><br/>
          Овладение компетенцией сохранной перевалки <br/>
          и перевозки экспортной газетной бумаги в рулонах (массового груза в доцифровую эпоху) позволило привлечь крупнейших мировых трейдеров и превратить КМТП в главный хаб <br/>
          для экспорта российской бумаги по всему миру. <br/><br/>
          В 1995 году был запущен еженедельный сервис Калининград / Киль / Калининград — бумага <br/>
          в рулонах для немецкого рынка перевозилась конвенционально «под палубой», а в контейнерах океанских линий - для получателей в странах Америки, Африки и Юго-Восточной Азии.<br/>
          Одновременно осуществлялись перевозки традиционного контейнерного экспорта/импорта.
        </>
      ),
      images: [
        { width: 430, height: 289, left: 630, top: 103, src: '/images/main2.png' },
        { width: 240, height: 322, left: 1080, top: 103, src: '/images/main3.png' },
      ],
      height: 678,
    },
    {
      year: '1996',
      text: 'Регистрация ООО «ТрансМарин»',
      images: [
        { width: 670, height: 440, left: 650, top: 62, src: '/images/main5.png' },
      ],
      height: 562,
    },
    {
      year: (
        <>
          В основе<br/>— знания
        </>
      ),
      text: (
        <>
          С самого начала мы сделали ставку на непрерывное обучение. Наши специалисты регулярно проходят курсы ведущих мировых институтов, таких как Lloyd's Maritime Academy, BIMCO и др. Мы инвестируем в знания, чтобы предлагать клиентам решения, основанные на глубоком понимании всех аспектов морской логистики.
        </>
      ),
      images: [
        { width: 670, height: 422, left: 650, top: 60, src: '/images/main4.png' },
      ],
      height: 562,
    },
  ];

  return (
    <>
      <section className="history-page">
        <div className="history-page__container">
          <Breadcrumbs />
          <h1 className="history-page__title">История TransMarine</h1>
        </div>
      </section>
      {historySections.map((section, index) => (
        <HistoryTimeline
          key={index}
          year={section.year}
          text={section.text}
          images={section.images}
        />
      ))}
      <Footer />
    </>
  );
}
